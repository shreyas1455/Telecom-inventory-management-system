let products = [
    { id: 1, name: "Cisco ISR 1101", modalNumber: "XYZ123",stock: 500, reorderPoint: 150  },
    { id: 2, name: "HP 5406zl",modalNumber: "ABC456", stock: 300, reorderPoint: 100  },
    { id: 3, name: "DOCSIS 3.1 Modem",modalNumber: "LMN789" ,stock: 200, reorderPoint: 50 },
  ];
  
  let suppliers = [
    { id: 1, name: "Cisco", contact: "cisco@mail.com" },
    { id: 2, name: "HP", contact: "hp@mail.com" },
    { id: 3, name: "Netgear", contact: "netgear@mail.com" },
  ];

  function renderProducts() {
    const tableBody = document.getElementById("products-table").querySelector("tbody");
    tableBody.innerHTML = "";
    products.forEach((product) => {
      tableBody.innerHTML += 
        `<tr>
          <td>${product.id}</td>
          <td>${product.name}</td>
          <td>${product.modalNumber}</td>
          <td>${product.stock}</td>
          <td>${product.reorderPoint}</td>
          
          <td><button onclick="editProduct(${product.id})">Edit</button></td>
        </tr>`;
    });
  }
  
  function renderSuppliers() {
    const tableBody = document.getElementById("suppliers-table").querySelector("tbody");
    tableBody.innerHTML = "";
    suppliers.forEach((supplier) => {
      tableBody.innerHTML += 
        `<tr>
          <td>${supplier.id}</td>
          <td>${supplier.name}</td>
          <td>${supplier.contact}</td>
          <td><button onclick="editSupplier(${supplier.id})">Edit</button></td>
        </tr>`;
    });
  }
  
  function populateProductDropdown() {
    const productSelect = document.getElementById("productId");
    products.forEach((product) => {
      const option = document.createElement("option");
      option.value = product.id;
      option.textContent = product.name;
      productSelect.appendChild(option);
    });
  }
  
  
  
    function editProduct(productId) {
        const product = products.find(p => p.id === productId);
      
        if (product) {
          const newName = prompt("Enter new name:", product.name);
          if (newName) product.name = newName;
      
          const newModelNumber = prompt("Enter new modal number:", product.modalNumber);
          if (newModelNumber) product.modalNumber = newModelNumber;
      
          const newReorderPoint = prompt("Enter new reorder point:", product.reorderPoint);
          if (newReorderPoint) product.reorderPoint = parseInt(newReorderPoint);
      
          const newStock = prompt("Enter new stock:", product.stock);
          if (newStock) product.stock = parseInt(newStock); 
      
          renderProducts();
        }
      }
  
  function editSupplier(id) {
    const supplier = suppliers.find((s) => s.id === id);
    if (supplier) {
      const newName = prompt("Enter new name:", supplier.name);
      if (newName !== null) supplier.name = newName;

      const newContact = prompt("Enter new contact:", supplier.contact);
      if (newContact !== null) supplier.contact = newContact;
      renderSuppliers();
    }
  }
  
  document.getElementById("transaction-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const productId = parseInt(document.getElementById("productId").value);
    const transactionType = document.getElementById("transactionType").value;
    const quantity = parseInt(document.getElementById("quantity").value);
  
    const product = products.find((p) => p.id === productId);
    if (product) {
      if (transactionType === "add") product.stock += quantity;
      else if (transactionType === "remove") product.stock -= quantity;
      renderProducts();
    }
  });
  
  renderProducts();
  renderSuppliers();
  populateProductDropdown();
  